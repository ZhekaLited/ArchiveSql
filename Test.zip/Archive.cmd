set PATH=%PATH%;C:\Program Files\jdk-17.0.1\bin
jar tf ArchiveAuto2.jar
jar cf ArchiveAuto2.jar Auto2
pause
