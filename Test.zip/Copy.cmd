mkdir Auto2 
xcopy /e "Auto" "Auto2"
pause